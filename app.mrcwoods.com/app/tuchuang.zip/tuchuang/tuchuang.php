<?php
/*
Plugin Name: 图床
Plugin URI: https://img.scdn.io
Description: 自动将上传到WordPress媒体库的图片转存到指定的图床，并替换URL。
Version: 1.3.0
Author: 人模狗样
Author URI: https://img.scdn.io
*/

if (!defined('ABSPATH')) {
    exit; // 如果不是WordPress环境，直接退出
}

// 定义图床API的URL
define('SCV_CDN_API_URL', 'https://img.scdn.io/api/v1.php');

// 注册插件设置
add_action('admin_init', 'scdn_register_settings');
function scdn_register_settings() {
    register_setting(
        'scdn_settings_group', // 设置组的名称
        'scdn_output_format',   // 选项名称
        [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 'auto',
        ]
    );
}

// 添加后台菜单
add_action('admin_menu', 'scdn_add_admin_menu');
function scdn_add_admin_menu() {
    add_options_page(
        '图床设置', // 页面标题
        '图床',           // 菜单标题
        'manage_options',    // 所需权限
        'scdn-settings',     // 菜单的slug
        'scdn_settings_page' // 显示设置页面的函数
    );
}

// 渲染设置页面
function scdn_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

        <div class="notice notice-warning is-dismissible" style="padding: 1rem;">
            <p><strong>重要提示：</strong></p>
            <p>请不要轻易禁用或卸载本插件。禁用或卸载将导致之前通过本插件上传的所有图片在您的网站上无法显示（链接失效）。</p>
            <p>但请放心，您的图片文件本身仍然安全地存储在图床服务器上，并不会丢失。</p>
        </div>

        <form action="options.php" method="post">
            <?php
            settings_fields('scdn_settings_group'); // 输出安全字段
            do_settings_sections('scdn-settings');   // 输出设置区域（如果定义了的话）
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="scdn_output_format">图片输出格式</label></th>
                    <td>
                        <select id="scdn_output_format" name="scdn_output_format">
                            <option value="auto" <?php selected(get_option('scdn_output_format', 'auto'), 'auto'); ?>>自动 (推荐)</option>
                            <option value="jpeg" <?php selected(get_option('scdn_output_format'), 'jpeg'); ?>>JPEG</option>
                            <option value="png" <?php selected(get_option('scdn_output_format'), 'png'); ?>>PNG</option>
                            <option value="webp" <?php selected(get_option('scdn_output_format'), 'webp'); ?>>WebP (静态)</option>
                            <option value="gif" <?php selected(get_option('scdn_output_format'), 'gif'); ?>>GIF</option>
                            <option value="webp_animated" <?php selected(get_option('scdn_output_format'), 'webp_animated'); ?>>WebP (动态)</option>
                        </select>
                        <p class="description">选择上传到图床后希望转换成的图片格式。“自动”模式下，静态图将转为WebP，动态图将转为动态WebP。</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('保存更改'); ?>
        </form>
    </div>
    <?php
}

// 挂载到 'wp_generate_attachment_metadata' 钩子，这个钩子在附件元数据生成后触发
add_filter('wp_generate_attachment_metadata', 'scdn_handle_upload', 20, 2);

/**
 * 核心处理函数：拦截上传的图片，发送到图床并处理返回结果
 *
 * @param array $metadata 附件的元数据.
 * @param int   $attachment_id 附件ID.
 * @return array 修改后的元数据.
 */
function scdn_handle_upload($metadata, $attachment_id)
{
    // 1. 检查是否为图片类型
    if (!wp_attachment_is_image($attachment_id)) {
        return $metadata;
    }

    // 2. 获取文件的绝对路径
    $file_path = get_attached_file($attachment_id);
    if (!$file_path || !file_exists($file_path)) {
        // 如果文件不存在，记录日志并返回
        error_log("SCV-CDN Uploader: File not found for attachment ID {$attachment_id}.");
        return $metadata;
    }

    // 获取保存的输出格式设置
    $output_format = get_option('scdn_output_format', 'auto');

    // 3. 使用 cURL 将图片上传到图床
    $ch = curl_init();
    $cfile = new CURLFile($file_path, mime_content_type($file_path), basename($file_path));
    $post_data = [
        'image' => $cfile,
        'outputFormat' => $output_format, // 添加输出格式参数
    ];

    curl_setopt($ch, CURLOPT_URL, SCV_CDN_API_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    // 在生产环境中，建议开启SSL验证
    // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    // 4. 处理上传结果
    if ($curl_error || $http_code !== 200) {
        // 如果cURL出错或HTTP状态码不是200，记录错误并返回
        error_log("SCV-CDN Uploader cURL/HTTP Error: (Code: {$http_code}) " . $curl_error . " - Response: " . $response);
        // 此处可以选择是否向用户显示错误提示
        return $metadata;
    }

    $result = json_decode($response, true);

    // 5. 验证图床API的返回数据
    if (isset($result['success']) && $result['success'] === true && !empty($result['url'])) {
        $remote_url = $result['url'];

        // a. 将图床返回的URL存储在附件的meta信息中，方便后续调用
        update_post_meta($attachment_id, '_scdn_url', $remote_url);
        
        // b. [重要] 根据用户要求，删除本地服务器上的图片（包括所有缩略图）
        // 这可以节省服务器存储空间
        $upload_dir = wp_upload_dir();
        // 删除主文件
        if (file_exists($file_path)) {
            unlink($file_path);
        }
        // 删除所有尺寸的缩略图
        if (isset($metadata['sizes']) && is_array($metadata['sizes'])) {
            foreach ($metadata['sizes'] as $size => $size_data) {
                $thumb_file = $upload_dir['basedir'] . '/' . dirname($metadata['file']) . '/' . $size_data['file'];
                if (file_exists($thumb_file)) {
                    unlink($thumb_file);
                }
            }
        }

        // c. 清空文件元数据中的本地文件路径信息
        // 这可以防止WordPress在后台媒体库中显示裂开的图片
        $metadata['file'] = '';
        $metadata['sizes'] = [];

        // 记录成功日志
        error_log("SCV-CDN Uploader: Successfully uploaded attachment ID {$attachment_id} to {$remote_url}");

    } else {
        // 如果API返回失败，记录错误信息
        $error_message = isset($result['message']) ? $result['message'] : 'Unknown API error.';
        error_log("SCV-CDN Uploader API Error for attachment ID {$attachment_id}: " . $error_message);
    }
    
    return $metadata;
}

/**
 * 过滤附件的URL，如果已上传到图床，则返回图床URL
 *
 * @param string $url 原始附件URL.
 * @param int    $attachment_id 附件ID.
 * @return string 替换后的URL.
 */
function scdn_get_attachment_url($url, $attachment_id)
{
    $remote_url = get_post_meta($attachment_id, '_scdn_url', true);
    return $remote_url ? $remote_url : $url;
}
add_filter('wp_get_attachment_url', 'scdn_get_attachment_url', 10, 2);


/**
 * 过滤图片元素的 src, 确保在文章中插入的图片使用图床URL
 *
 * @param array|false  $image         图片属性数组 (url, width, height, is_intermediate) 或 false.
 * @param int          $attachment_id 附件ID.
 * @param string|array $size          请求的图片尺寸.
 * @param bool         $icon          是否为图标.
 * @return array|false
 */
function scdn_get_attachment_image_src($image, $attachment_id, $size, $icon)
{
    $remote_url = get_post_meta($attachment_id, '_scdn_url', true);
    if ($remote_url && is_array($image)) {
        $image[0] = $remote_url; // 将数组中的URL替换为图床URL
    }
    return $image;
}
add_filter('wp_get_attachment_image_src', 'scdn_get_attachment_image_src', 10, 4);

/**
 * 兼容Gutenberg编辑器(区块编辑器)，确保在编辑器中也返回正确的URL
 *
 * @param array   $response   JS准备的附件数据.
 * @param WP_Post $attachment 附件对象.
 * @param array   $meta       附件元数据.
 * @return array
 */
function scdn_prepare_attachment_for_js($response, $attachment, $meta)
{
    $remote_url = get_post_meta($attachment->ID, '_scdn_url', true);
    if ($remote_url) {
        $response['url'] = $remote_url;
        // 确保所有尺寸都指向远程URL
        if (isset($response['sizes']) && is_array($response['sizes'])) {
            foreach ($response['sizes'] as $size => &$size_data) {
                $size_data['url'] = $remote_url;
            }
        }
    }
    return $response;
}
add_filter('wp_prepare_attachment_for_js', 'scdn_prepare_attachment_for_js', 10, 3);