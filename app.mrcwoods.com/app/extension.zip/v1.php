<?php
// api/v1.php - Public API Endpoint

// --- CORS Headers ---
// 允许来自任何来源的请求
header("Access-Control-Allow-Origin: *");
// 允许的请求方法
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
// 允许的请求头
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

// 当浏览器发送 'OPTIONS' 预检请求时，直接返回成功状态
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json');

require_once '../config/database.php';
require_once '../includes/functions.php';

/**
 * 检查上传的文件是否为动态图片 (GIF 或 动态 WebP).
 * @param string $tmp_path 文件的临时路径.
 * @param string $file_extension 文件的小写扩展名.
 * @return bool 如果是动态图片则返回 true, 否则返回 false.
 */
function is_input_animated($tmp_path, $file_extension) {
    if ($file_extension === 'gif') {
        return true;
    }
    if ($file_extension === 'webp') {
        // 通过读取文件头部的一小部分并查找 'ANIM' 块来检查动态 WebP.
        // 这是一个相当可靠的指标，并且比解析整个 RIFF 结构更高效.
        $handle = @fopen($tmp_path, 'r');
        if (!$handle) {
            return false;
        }
        // 通常 'ANIM' 出现在文件早期. 读取前 100 字节足够了.
        $chunk = fread($handle, 100);
        fclose($handle);
        if (strpos($chunk, 'ANIM') !== false) {
            return true;
        }
    }
    return false;
}

// --- 1. 速率限制 ---
session_start();
$rate_limit_seconds = 5;
if (isset($_SESSION['last_api_call']) && (time() - $_SESSION['last_api_call']) < $rate_limit_seconds) {
    http_response_code(429); // Too Many Requests
    echo json_encode(['success' => false, 'message' => '请求过于频繁，请稍后再试。']);
    exit;
}

// --- 2. 验证请求方法和文件 ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => '仅支持POST方法。']);
    exit;
}

if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => '没有文件被上传或上传时发生错误。请确保您上传的字段名为 "image"。']);
    exit;
}

$file = $_FILES['image'];
$tmp_path = $file['tmp_name'];

// --- 关键安全修复：验证文件内容是否为真实图片 ---
$image_info = @getimagesize($tmp_path);
if ($image_info === false) {
    // 这不是一个有效的图片文件，立即拒绝
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => '上传的文件不是有效的图片。']);
    // 清理临时文件并退出
    @unlink($tmp_path);
    exit;
}
// --- 安全修复结束 ---

// --- 3. 文件类型和大小验证 (与主上传接口保持一致) ---
$allowed_extensions = ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'tiff', 'avif', 'gif'];
$file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if (!in_array($file_extension, $allowed_extensions)) {
    http_response_code(415); // Unsupported Media Type
    echo json_encode(['success' => false, 'message' => '不支持的文件格式。']);
    exit;
}

// --- 4. 执行上传和压缩逻辑 (与主上传接口的核心逻辑相同) ---
try {
    $conn = get_db_connection();
    if (!$conn) {
        throw new Exception("无法连接到数据库。");
    }

    // 在此之前获取所有设置
    $settings = get_all_settings();

    // 从POST请求中获取目标输出格式
    $outputFormat = $_POST['outputFormat'] ?? 'auto';

    // 根据输入文件类型和用户选择，确定最终要存入数据库的格式，解决'auto'的歧义
    $is_animated = is_input_animated($tmp_path, $file_extension);

    $final_output_format_for_db = $outputFormat;
    if ($outputFormat === 'auto') {
        if ($is_animated) {
            $final_output_format_for_db = 'webp_animated';
        } else {
            $final_output_format_for_db = 'webp';
        }
    }

    // --- 服务端文件大小验证 ---
    $max_size_mb = 0;
    if ($outputFormat === 'auto') {
        $max_size_mb = max(
            (int)($settings['max_size_jpg'] ?? 5),
            (int)($settings['max_size_png'] ?? 3),
            (int)($settings['max_size_webp'] ?? 20),
            (int)($settings['max_size_gif'] ?? 15),
            (int)($settings['max_size_webp_animated'] ?? 15)
        );
    } else {
        $key = 'max_size_' . strtolower($outputFormat);
        if (isset($settings[$key])) {
            $max_size_mb = (int)$settings[$key];
        } else {
            // 如果没有为特定格式找到设置，使用一个合理的默认值或最大值
            $max_size_mb = 20; // 默认使用最大可能的20MB作为后备
        }
    }

    $max_size_bytes = $max_size_mb * 1024 * 1024;
    if ($file['size'] > $max_size_bytes) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "文件大小超过了所选格式 (${outputFormat}) 的 ${max_size_mb}MB 限制。"]);
        exit;
    }

    // --- 新增：加密图片大小限制 ---
    if (isset($_POST['password_enabled']) && $_POST['password_enabled'] === 'true' && !empty($_POST['image_password'])) {
        $max_size_encrypted_mb = 1;
        $max_size_encrypted_bytes = $max_size_encrypted_mb * 1024 * 1024;
        if ($file['size'] > $max_size_encrypted_bytes) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => "加密图片最大只支持 {$max_size_encrypted_mb}MB。"]);
            exit;
        }
    }
    // --- 限制结束 ---

    // --- 5. 执行上传和压缩逻辑 ---
    // (这部分现在与 api/upload.php 完全相同)
    $original_file_hash = hash_file('sha256', $tmp_path);

    // --- 新的、分阶段的秒传逻辑 (与 upload.php 完全一致) ---

    // 阶段1: 检查上传文件本身是否是【已存在的压缩图】
    $stmt = $conn->prepare("SELECT filename, password FROM images WHERE compressed_file_hash = ? LIMIT 1");
    $stmt->bind_param('s', $original_file_hash);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $existing_image = $result->fetch_assoc();
        $image_url = get_image_url($existing_image['filename'], !empty($existing_image['password']));
        $stmt->close();
        
        $_SESSION['last_api_call'] = time(); // 秒传也算一次调用
        echo json_encode([
            'success' => true, 
            'url' => $image_url,
            'message' => '图片已存在，秒传成功！'
        ]);
        $conn->close();
        exit;
    }
    $stmt->close();

    // --- 阶段 2: 检查【原图哈希 + 目标输出格式】的组合是否已存在 (终极方案) ---
    $check_stmt = $conn->prepare("SELECT filename, password FROM images WHERE file_hash = ? AND output_format = ? LIMIT 1");
    $check_stmt->bind_param('ss', $original_file_hash, $final_output_format_for_db);

    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        $existing_image = $result->fetch_assoc();
        $image_url = get_image_url($existing_image['filename'], !empty($existing_image['password']));
        $check_stmt->close();

        $_SESSION['last_api_call'] = time();
        echo json_encode([
            'success' => true, 
            'url' => $image_url,
            'message' => '图片已存在，秒传成功！'
        ]);
        $conn->close();
        exit;
    }
    $check_stmt->close();

    $settings = get_all_settings();
    $file_size = $file['size'];
    $skip_compression_threshold = 30 * 1024; // 30KB

    $compressed_data = null;
    $api_result = [];

    if ($file_size > $skip_compression_threshold) {
        // 调用压缩API
        $api_url = $settings['compression_api_url'] ?? 'https://compress.scdn.io/api/compress.php';
        $api_key = $settings['compression_api_key'] ?? '';

        // --- 动态获取压缩质量 (新逻辑) ---
        // 1. 默认使用全局质量
        $quality = $settings['compression_quality'] ?? 85;
        
        // 2. 确定用于查找质量设置的目标格式
        $format_for_quality_lookup = $final_output_format_for_db;
        
        // 3. 查找特定格式的质量设置
        if ($format_for_quality_lookup !== 'auto') {
            // 兼容 jpg 和 jpeg
            $key_format = ($format_for_quality_lookup === 'jpg') ? 'jpeg' : $format_for_quality_lookup;
            $specific_quality_key = 'compression_quality_' . $key_format;
            
            // 如果存在特定格式的设置，则覆盖全局质量
            if (isset($settings[$specific_quality_key]) && $settings[$specific_quality_key] !== '' && is_numeric($settings[$specific_quality_key])) {
                $quality = (int)$settings[$specific_quality_key];
            }
        }
        // --- 动态获取压缩质量结束 ---

        $curl_file = new CURLFile($tmp_path, $file['type'], $file['name']);
        $post_data = [
            'image' => $curl_file,
            'quality' => $quality,
            'outputFormat' => $final_output_format_for_db,
            'apiKey' => $api_key
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api_url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 120);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($curl_error || $http_code != 200) {
            throw new Exception("调用压缩API失败: " . ($curl_error ? "cURL Error - " . $curl_error : "HTTP " . $http_code));
        }
        
        $api_result = json_decode($response, true);
        if (!$api_result || !isset($api_result['success']) || $api_result['success'] === false) {
            throw new Exception('图片压缩失败: ' . ($api_result['error'] ?? '未知压缩错误'));
        }

        $compressed_data = base64_decode($api_result['data']);
        if ($compressed_data === false) {
            throw new Exception('无法解码压缩后的图片数据');
        }
    } else {
        // 小于5KB，直接读取原文件内容
        $compressed_data = file_get_contents($tmp_path);
        if ($compressed_data === false) {
            throw new Exception('无法读取临时上传文件。');
        }
        // 模拟API返回的结构
        $api_result = [
            'originalSize' => $file_size,
            'compressedSize' => $file_size,
            'format' => $file['type']
        ];
    }

    // 计算压缩后文件的哈希值
    $compressed_file_hash = hash('sha256', $compressed_data);

    // --- 保存时更精确 (与 api/upload.php 完全一致) ---
    $final_extension = $final_output_format_for_db;
    if ($final_output_format_for_db === 'webp_animated') {
        $final_extension = 'webp';
    }
    $mime_type = $api_result['format'] ?? ($file['type'] ?? 'application/octet-stream');
    
    // 处理图片密码 (新增)
    $password_to_store = null;
    $has_password = false;
    if (isset($_POST['password_enabled']) && $_POST['password_enabled'] === 'true') {
        if (!empty($_POST['image_password'])) {
            $password_to_store = password_hash($_POST['image_password'], PASSWORD_DEFAULT);
            $has_password = true;
        }
    }

    // 根据是否有密码生成文件名和路径
    $new_filename = uniqid() . '_' . time() . '.' . $final_extension;
    $upload_dir = $has_password ? '/uploads/uploads_private/' : '/uploads/';
    $upload_path = dirname(__DIR__) . $upload_dir . $new_filename;

    // 核心判断：如果压缩后比原图还大，则不保存并报错
    if (strlen($compressed_data) > $file['size']) {
        // 清理临时文件，以防万一
        @unlink($tmp_path);
        // 返回包含大小信息的详细错误
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => "图片大小异常，这可能是因为选择了不明智的输出格式或异常的图片导致的",
            'data' => [
                'originalSize' => $file['size'],
                'compressedSize' => strlen($compressed_data)
            ]
        ]);
        exit;
    }

    if (!file_put_contents($upload_path, $compressed_data)) {
        throw new Exception("无法将文件保存到上传目录。");
    }

    $original_filename = $file['name'];
    $original_size = $api_result['originalSize'];
    $compressed_size = $api_result['compressedSize'];
    $uploader_ip = get_client_ip();
    
    // 将图片信息和密码（如果存在）存入数据库
    $stmt = $conn->prepare("INSERT INTO images (filename, original_filename, original_size, compressed_size, compression_quality, file_hash, compressed_file_hash, output_format, mime_type, password, uploader_ip, upload_date, last_accessed_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
    $stmt->bind_param('ssiiissssss', $new_filename, $original_filename, $original_size, $compressed_size, $quality, $original_file_hash, $compressed_file_hash, $final_output_format_for_db, $mime_type, $password_to_store, $uploader_ip);
    
    if (!$stmt->execute()) {
        throw new Exception("数据库插入失败: " . $stmt->error);
    }
    
    $_SESSION['last_api_call'] = time();
    
    $image_url = get_image_url($new_filename, $has_password);
    echo json_encode([
        'success' => true,
        'url' => $image_url,
        'data' => [
            'filename' => $new_filename,
            'original_size' => $original_size,
            'compressed_size' => $compressed_size,
            'compression_ratio' => $original_size > 0 ? round((1 - $compressed_size / $original_size) * 100, 2) : 0
        ]
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    if ($conn) {
        $conn->close();
    }
} 