document.addEventListener('DOMContentLoaded', () => {
    // ========== DOM Elements ==========
    // Tabs
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    // Upload Tab
    const uploadArea = document.getElementById('upload-area');
    const fileInput = document.getElementById('file-input');
    const previewArea = document.getElementById('preview-area');
    const imagePreview = document.getElementById('image-preview');
    const removeImageBtn = document.getElementById('remove-image');
    const outputFormatSelect = document.getElementById('outputFormat');
    const uploadBtn = document.getElementById('upload-btn');
    const resultDiv = document.getElementById('result');
    const resultUrlLink = document.getElementById('result-url');
    const copyBtn = document.getElementById('copy-btn');
    const progressContainer = document.getElementById('progress-container');
    const progressBar = document.getElementById('progress');
    const progressText = document.getElementById('progress-text');
    const errorMessageDiv = document.getElementById('error-message');
    
    // Sniffer Tab
    const sniffBtn = document.getElementById('sniff-btn');
    const snifferActions = document.getElementById('sniffer-actions');
    const snifferFilter = document.getElementById('sniffer-filter');
    const filterInput = document.getElementById('filter-input');
    const sizeFilter = document.getElementById('size-filter');
    const selectAllBtn = document.getElementById('select-all-btn');
    const downloadSelectedBtn = document.getElementById('download-selected-btn');
    const uploadSelectedBtn = document.getElementById('upload-selected-btn');
    const snifferStatus = document.getElementById('sniffer-status');
    const snifferEmpty = document.getElementById('sniffer-empty');
    const snifferResults = document.getElementById('sniffer-results');
    const snifferError = document.getElementById('sniffer-error');
    const snifferBadge = document.getElementById('sniffer-badge');
    const batchProgress = document.getElementById('batch-progress');
    const batchProgressBar = document.getElementById('batch-progress-bar');
    const batchProgressText = document.getElementById('batch-progress-text');
    
    // Footer
    const openOptionsBtn = document.getElementById('open-options');
    const clearHistoryBtn = document.getElementById('clear-history-btn');
    const historyList = document.getElementById('history-list');

    // ========== State ==========
    let selectedFile = null;
    let sniffedImages = [];
    let selectedImages = new Set();
    let isBatchUploading = false;

    // ========== Tab Navigation ==========
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.dataset.tab;
            
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            tabContents.forEach(content => {
                content.classList.remove('active');
                if (content.id === `tab-${tabId}`) {
                    content.classList.add('active');
                }
            });
        });
    });

    // ========== Upload Tab ==========
    // 点击上传区域时触发文件选择
    uploadArea.addEventListener('click', () => {
        fileInput.click();
    });

    // Drag and drop events
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFile(files[0]);
        }
    });

    // File input change
    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            handleFile(fileInput.files[0]);
        }
    });
    
    // Remove selected image
    removeImageBtn.addEventListener('click', () => {
        selectedFile = null;
        fileInput.value = '';
        previewArea.style.display = 'none';
        uploadArea.style.display = 'block';
        uploadBtn.disabled = true;
        resetResult();
    });
    
    // Upload button click
    uploadBtn.addEventListener('click', uploadImage);

    // Copy button click
    copyBtn.addEventListener('click', () => {
        const urlToCopy = resultUrlLink.href;
        if (urlToCopy && urlToCopy !== '#') {
            navigator.clipboard.writeText(urlToCopy).then(() => {
                copyBtn.textContent = '已复制!';
                setTimeout(() => {
                    copyBtn.textContent = '复制';
                }, 2000);
            });
        }
    });

    // ========== Sniffer Tab ==========
    sniffBtn.addEventListener('click', sniffImages);
    
    selectAllBtn.addEventListener('click', () => {
        const allSelected = selectedImages.size === sniffedImages.length;
        if (allSelected) {
            selectedImages.clear();
            selectAllBtn.textContent = '全选';
        } else {
            sniffedImages.forEach(img => selectedImages.add(img.url));
            selectAllBtn.textContent = '取消全选';
        }
        renderSnifferResults();
    });
    
    downloadSelectedBtn.addEventListener('click', downloadSelectedImages);
    uploadSelectedBtn.addEventListener('click', uploadSelectedImages);
    
    filterInput.addEventListener('input', renderSnifferResults);
    sizeFilter.addEventListener('change', renderSnifferResults);

    // ========== Footer ==========
    openOptionsBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (chrome.runtime.openOptionsPage) {
            chrome.runtime.openOptionsPage();
        } else {
            window.open(chrome.runtime.getURL('options.html'));
        }
    });

    clearHistoryBtn.addEventListener('click', (e) => {
        e.preventDefault();
        chrome.storage.local.set({ uploadHistory: [] }, () => {
            renderHistory([]);
        });
    });

    // ========== Functions ==========
    
    // --- Upload Functions ---
    function handleFile(file) {
        if (!file.type.startsWith('image/')) {
            showError('请选择一个图片文件。');
            return;
        }
        selectedFile = file;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            imagePreview.src = e.target.result;
            uploadArea.style.display = 'none';
            previewArea.style.display = 'block';
            uploadBtn.disabled = false;
            resetResult();
        };
        reader.readAsDataURL(file);
    }

    async function uploadImage() {
        if (!selectedFile) return;

        const { apiUrl } = await chrome.storage.sync.get({ apiUrl: '' });
        if (!apiUrl) {
            showError('请先在设置页面配置API上传地址。');
            chrome.runtime.openOptionsPage();
            return;
        }

        resetResult();
        progressContainer.style.display = 'block';
        uploadBtn.disabled = true;
        uploadBtn.textContent = '上传中...';

        const formData = new FormData();
        formData.append('image', selectedFile);
        formData.append('outputFormat', outputFormatSelect.value);
        
        try {
            const response = await fetchWithProgress(apiUrl, {
                method: 'POST',
                body: formData,
            }, (progress) => {
                updateProgress(progress.loaded, progress.total);
            });
            
            const data = await response.json();

            if (data.success) {
                resultDiv.style.display = 'block';
                resultUrlLink.href = data.url;
                resultUrlLink.textContent = data.url;
                saveSettings();
                saveToHistory(data.url);
            } else {
                showError(data.message || '上传失败，未知错误。');
            }

        } catch (error) {
            showError('上传失败，请检查网络连接或API地址。');
            console.error('Upload error:', error);
        } finally {
            uploadBtn.disabled = false;
            uploadBtn.textContent = '上传';
            progressContainer.style.display = 'none';
        }
    }
    
    function updateProgress(loaded, total) {
        if (total > 0) {
            const percent = Math.round((loaded / total) * 100);
            progressBar.style.width = percent + '%';
            progressText.textContent = `上传中... ${percent}%`;
        } else {
            progressBar.style.width = '100%';
            progressText.textContent = `上传中...`;
        }
    }
    
    async function fetchWithProgress(url, options, onProgress) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open(options.method || 'get', url);

            for (const key in options.headers) {
                xhr.setRequestHeader(key, options.headers[key]);
            }

            xhr.upload.addEventListener('progress', (e) => {
                if (e.lengthComputable) {
                    onProgress({ loaded: e.loaded, total: e.total });
                }
            });

            xhr.onload = () => {
                const responseHeaders = xhr.getAllResponseHeaders().split('\r\n')
                    .reduce((acc, current) => {
                        const [name, ...value] = current.split(': ');
                        if (name) acc[name] = value.join(': ');
                        return acc;
                    }, {});

                const response = new Response(xhr.responseText, {
                    status: xhr.status,
                    statusText: xhr.statusText,
                    headers: responseHeaders,
                });
                resolve(response);
            };
            
            xhr.onerror = () => {
                reject(new Error('请求失败 (network error)'));
            };
            
            xhr.send(options.body);
        });
    }

    // --- Sniffer Functions ---
    async function sniffImages() {
        sniffBtn.disabled = true;
        snifferStatus.style.display = 'flex';
        snifferEmpty.style.display = 'none';
        snifferResults.innerHTML = '';
        snifferError.style.display = 'none';
        snifferActions.style.display = 'none';
        snifferFilter.style.display = 'none';
        
        try {
            // 获取当前活动标签页
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            if (!tab) {
                showSnifferError('无法获取当前标签页');
                return;
            }
            
            // 注入内容脚本并执行嗅探
            const results = await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: sniffImagesInPage
            });
            
            if (results && results[0] && results[0].result) {
                sniffedImages = results[0].result;
                selectedImages.clear();
                
                if (sniffedImages.length > 0) {
                    snifferActions.style.display = 'flex';
                    snifferFilter.style.display = 'flex';
                    renderSnifferResults();
                    updateBadge();
                } else {
                    snifferEmpty.style.display = 'flex';
                }
            } else {
                snifferEmpty.style.display = 'flex';
            }
        } catch (error) {
            console.error('Sniff error:', error);
            showSnifferError('扫描失败: ' + error.message);
        } finally {
            sniffBtn.disabled = false;
            snifferStatus.style.display = 'none';
        }
    }
    
    // 在页面中执行的嗅探函数
    function sniffImagesInPage() {
        const images = [];
        const seen = new Set();
        
        // 1. 查找所有 img 标签
        document.querySelectorAll('img').forEach(img => {
            const url = img.src;
            if (url && !url.startsWith('data:') && !seen.has(url)) {
                seen.add(url);
                images.push({
                    url: url,
                    width: img.naturalWidth || img.width,
                    height: img.naturalHeight || img.height,
                    type: 'img'
                });
            }
        });
        
        // 2. 查找背景图片
        document.querySelectorAll('*').forEach(el => {
            const bg = window.getComputedStyle(el).backgroundImage;
            if (bg && bg !== 'none') {
                const match = bg.match(/url\(['"]?(.+?)['"]?\)/);
                if (match && match[1] && !match[1].startsWith('data:') && !seen.has(match[1])) {
                    seen.add(match[1]);
                    images.push({
                        url: match[1],
                        width: el.offsetWidth,
                        height: el.offsetHeight,
                        type: 'background'
                    });
                }
            }
        });
        
        // 3. 查找 picture 标签中的 source
        document.querySelectorAll('picture source').forEach(source => {
            const srcset = source.srcset;
            if (srcset) {
                srcset.split(',').forEach(s => {
                    const url = s.trim().split(' ')[0];
                    if (url && !url.startsWith('data:') && !seen.has(url)) {
                        seen.add(url);
                        images.push({
                            url: url,
                            width: 0,
                            height: 0,
                            type: 'source'
                        });
                    }
                });
            }
        });
        
        return images;
    }
    
    function renderSnifferResults() {
        const filterText = filterInput.value.toLowerCase();
        const sizeFilterValue = sizeFilter.value;
        
        let filtered = sniffedImages.filter(img => {
            // URL 筛选
            if (filterText && !img.url.toLowerCase().includes(filterText)) {
                return false;
            }
            
            // 大小筛选 (这里用尺寸估算，实际大小需要额外请求)
            if (sizeFilterValue !== 'all') {
                const pixels = img.width * img.height;
                if (sizeFilterValue === 'small' && pixels > 100000) return false;
                if (sizeFilterValue === 'medium' && (pixels <= 100000 || pixels > 1000000)) return false;
                if (sizeFilterValue === 'large' && pixels <= 1000000) return false;
            }
            
            return true;
        });
        
        snifferResults.innerHTML = '';
        
        if (filtered.length === 0) {
            snifferResults.innerHTML = '<div class="empty-state">没有符合条件的图片</div>';
            return;
        }
        
        filtered.forEach(img => {
            const isSelected = selectedImages.has(img.url);
            const item = document.createElement('div');
            item.className = `sniffer-item ${isSelected ? 'selected' : ''}`;
            
            item.innerHTML = `
                <div class="sniffer-item-checkbox">
                    <input type="checkbox" ${isSelected ? 'checked' : ''}>
                </div>
                <img class="sniffer-item-preview" src="${escapeHtml(img.url)}" alt="预览" onerror="this.style.display='none'">
                <div class="sniffer-item-info">
                    <div class="sniffer-item-url" title="${escapeHtml(img.url)}">${escapeHtml(img.url)}</div>
                    <div class="sniffer-item-meta">
                        <span>${img.width}×${img.height}</span>
                        <span>${img.type}</span>
                    </div>
                </div>
                <div class="sniffer-item-actions">
                    <button class="sniffer-item-btn download" data-url="${escapeHtml(img.url)}">下载</button>
                    <button class="sniffer-item-btn upload" data-url="${escapeHtml(img.url)}">上传</button>
                </div>
            `;
            
            // Checkbox 事件
            const checkbox = item.querySelector('input[type="checkbox"]');
            checkbox.addEventListener('change', () => {
                if (checkbox.checked) {
                    selectedImages.add(img.url);
                    item.classList.add('selected');
                } else {
                    selectedImages.delete(img.url);
                    item.classList.remove('selected');
                }
                updateSelectAllBtn();
            });
            
            // 下载按钮
            item.querySelector('.download').addEventListener('click', () => {
                downloadImage(img.url);
            });
            
            // 上传按钮
            item.querySelector('.upload').addEventListener('click', () => {
                uploadSingleImage(img.url);
            });
            
            snifferResults.appendChild(item);
        });
        
        updateSelectAllBtn();
    }
    
    function updateSelectAllBtn() {
        const filteredCount = snifferResults.querySelectorAll('.sniffer-item').length;
        const selectedCount = snifferResults.querySelectorAll('.sniffer-item.selected').length;
        
        if (selectedCount === filteredCount && filteredCount > 0) {
            selectAllBtn.textContent = '取消全选';
        } else {
            selectAllBtn.textContent = '全选';
        }
    }
    
    function updateBadge() {
        if (sniffedImages.length > 0) {
            snifferBadge.textContent = sniffedImages.length;
            snifferBadge.style.display = 'inline';
        } else {
            snifferBadge.style.display = 'none';
        }
    }
    
    async function downloadImage(url) {
        try {
            await chrome.runtime.sendMessage({ 
                action: 'downloadImage', 
                url: url 
            });
        } catch (error) {
            showSnifferError('下载失败: ' + error.message);
        }
    }
    
    async function downloadSelectedImages() {
        if (selectedImages.size === 0) {
            showSnifferError('请先选择要下载的图片');
            return;
        }
        
        const urls = Array.from(selectedImages);
        for (const url of urls) {
            await downloadImage(url);
            // 添加延迟避免同时下载太多
            await new Promise(resolve => setTimeout(resolve, 300));
        }
    }
    
    async function uploadSingleImage(url) {
        try {
            // 先切换到上传标签页显示进度
            tabBtns[0].click();
            
            // 获取图片数据
            const response = await fetch(url);
            const blob = await response.blob();
            
            // 转换为 File 对象
            const filename = url.split('/').pop().split('?')[0] || 'image.png';
            selectedFile = new File([blob], filename, { type: blob.type });
            
            // 显示预览
            const reader = new FileReader();
            reader.onload = (e) => {
                imagePreview.src = e.target.result;
                uploadArea.style.display = 'none';
                previewArea.style.display = 'block';
                uploadBtn.disabled = false;
                resetResult();
            };
            reader.readAsDataURL(blob);
            
        } catch (error) {
            showError('获取图片失败: ' + error.message);
        }
    }
    
    async function uploadSelectedImages() {
        if (selectedImages.size === 0) {
            showSnifferError('请先选择要上传的图片');
            return;
        }
        
        if (isBatchUploading) return;
        isBatchUploading = true;
        
        const urls = Array.from(selectedImages);
        const total = urls.length;
        let successCount = 0;
        let failCount = 0;
        
        batchProgress.style.display = 'block';
        batchProgressBar.style.width = '0%';
        batchProgressText.textContent = `0/${total}`;
        
        for (let i = 0; i < urls.length; i++) {
            const url = urls[i];
            batchProgressText.textContent = `${i + 1}/${total}`;
            batchProgressBar.style.width = `${((i + 1) / total * 100)}%`;
            
            try {
                const result = await chrome.runtime.sendMessage({
                    action: 'uploadFromUrl',
                    url: url
                });
                
                if (result && result.success) {
                    successCount++;
                } else {
                    failCount++;
                }
            } catch (error) {
                failCount++;
                console.error('Batch upload error:', error);
            }
            
            // 延迟避免请求过快
            if (i < urls.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        }
        
        batchProgress.style.display = 'none';
        isBatchUploading = false;
        
        // 刷新历史记录
        loadHistory();
        
        // 显示结果
        showSnifferError(`批量上传完成！成功: ${successCount}, 失败: ${failCount}`);
    }
    
    function showSnifferError(message) {
        snifferError.textContent = message;
        snifferError.style.display = 'block';
    }

    // --- Utility Functions ---
    function showError(message) {
        errorMessageDiv.textContent = message;
        errorMessageDiv.style.display = 'block';
    }

    function resetResult() {
        resultDiv.style.display = 'none';
        resultUrlLink.href = '#';
        resultUrlLink.textContent = '';
        errorMessageDiv.style.display = 'none';
        copyBtn.textContent = '复制';
        progressBar.style.width = '0%';
        progressText.textContent = '';
        progressContainer.style.display = 'none';
    }
    
    function escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    // --- History Functions ---
    const MAX_HISTORY_ITEMS = 15;

    async function saveToHistory(newUrl) {
        const result = await chrome.storage.local.get({ uploadHistory: [] });
        let history = result.uploadHistory;

        history.unshift({ url: newUrl, timestamp: new Date().toISOString() });

        if (history.length > MAX_HISTORY_ITEMS) {
            history = history.slice(0, MAX_HISTORY_ITEMS);
        }

        await chrome.storage.local.set({ uploadHistory: history });
        renderHistory(history);
    }

    async function loadHistory() {
        const result = await chrome.storage.local.get({ uploadHistory: [] });
        renderHistory(result.uploadHistory);
    }

    function renderHistory(history) {
        historyList.innerHTML = '';
        if (!history || history.length === 0) {
            const li = document.createElement('li');
            li.textContent = '暂无历史记录';
            li.style.justifyContent = 'center';
            li.style.color = 'var(--text-muted)';
            historyList.appendChild(li);
        } else {
            history.forEach(item => {
                const li = document.createElement('li');
                
                const img = document.createElement('img');
                img.className = 'history-preview';
                img.src = item.url;
                img.onerror = () => { img.style.display = 'none'; };

                const urlLink = document.createElement('a');
                urlLink.href = item.url;
                urlLink.target = '_blank';
                urlLink.title = item.url;
                
                const urlSpan = document.createElement('span');
                urlSpan.className = 'history-url';
                urlSpan.textContent = item.url;
                
                const copyHistoryBtn = document.createElement('button');
                copyHistoryBtn.className = 'copy-history-btn';
                copyHistoryBtn.textContent = '复制';
                copyHistoryBtn.addEventListener('click', () => {
                    navigator.clipboard.writeText(item.url).then(() => {
                        copyHistoryBtn.textContent = '已复制!';
                        setTimeout(() => {
                           copyHistoryBtn.textContent = '复制';
                        }, 2000);
                    }).catch(err => {
                        console.error('Failed to copy: ', err);
                    });
                });

                li.appendChild(img);
                urlLink.appendChild(urlSpan);
                li.appendChild(urlLink);
                li.appendChild(copyHistoryBtn);
                historyList.appendChild(li);
            });
        }
    }

    // --- Settings Functions ---
    function loadSettings() {
        chrome.storage.sync.get({
            outputFormat: 'auto'
        }, (items) => {
            outputFormatSelect.value = items.outputFormat;
        });
    }

    function saveSettings() {
        chrome.storage.sync.set({
            outputFormat: outputFormatSelect.value
        });
    }
    
    // --- Initial Load ---
    loadSettings();
    loadHistory();
    uploadBtn.disabled = true;
});