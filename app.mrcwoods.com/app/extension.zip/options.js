document.addEventListener('DOMContentLoaded', () => {
    const apiUrlInput = document.getElementById('api-url');
    const outputFormatSelect = document.getElementById('output-format');
    const dragUploadEnabledInput = document.getElementById('drag-upload-enabled');
    const saveBtn = document.getElementById('save-btn');
    const statusDiv = document.getElementById('status');

    // Load the saved API URL when the page loads
    function restoreOptions() {
        chrome.storage.sync.get({
            apiUrl: '',
            outputFormat: 'auto', // Default to 'auto'
            dragUploadEnabled: true // Default to true
        }, (items) => {
            apiUrlInput.value = items.apiUrl;
            outputFormatSelect.value = items.outputFormat;
            dragUploadEnabledInput.checked = items.dragUploadEnabled;
        });
    }

    // Save the API URL
    function saveOptions() {
        const apiUrl = apiUrlInput.value.trim();
        const outputFormat = outputFormatSelect.value;
        const dragUploadEnabled = dragUploadEnabledInput.checked;

        if (apiUrl) {
            // A simple validation for URL format
            try {
                new URL(apiUrl);
            } catch (e) {
                statusDiv.textContent = '错误: 无效的URL格式。';
                statusDiv.style.color = '#fa383e';
                setTimeout(() => { statusDiv.textContent = ''; }, 3000);
                return;
            }
            
            chrome.storage.sync.set({
                apiUrl: apiUrl,
                outputFormat: outputFormat,
                dragUploadEnabled: dragUploadEnabled
            }, () => {
                // Update status to let user know options were saved.
                statusDiv.textContent = '选项已保存。';
                statusDiv.style.color = '#1877f2';
                setTimeout(() => {
                    statusDiv.textContent = '';
                }, 2000);
            });
        } else {
             statusDiv.textContent = '错误: API地址不能为空。';
             statusDiv.style.color = '#fa383e';
             setTimeout(() => { statusDiv.textContent = ''; }, 3000);
        }
    }

    restoreOptions();
    saveBtn.addEventListener('click', saveOptions);
}); 