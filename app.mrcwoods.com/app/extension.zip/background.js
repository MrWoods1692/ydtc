// background.js (Service Worker)

const CONTEXT_MENU_ID = "upload_to_tuchuang";

// 创建右键菜单
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: CONTEXT_MENU_ID,
        title: "上传至图床",
        contexts: ["image"]
    });
    
    // 设置默认API
    chrome.storage.sync.get('apiUrl', (data) => {
        if (!data.apiUrl) {
            const defaultApiUrl = 'https://img.scdn.io/api/v1.php';
            chrome.storage.sync.set({ apiUrl: defaultApiUrl });
        }
    });
});

// 监听右键菜单点击事件
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === CONTEXT_MENU_ID) {
        const imageUrl = info.srcUrl;
        if (imageUrl) {
            handleImageUpload(imageUrl);
        }
    }
});

// 监听消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // 从URL上传图片
    if (request.action === 'uploadFromUrl' && request.url) {
        handleImageUpload(request.url).then(result => {
            sendResponse(result);
        }).catch(error => {
            sendResponse({ success: false, error: error.message });
        });
        return true;
    }
    
    // 下载图片
    if (request.action === 'downloadImage' && request.url) {
        downloadImage(request.url).then(() => {
            sendResponse({ success: true });
        }).catch(error => {
            sendResponse({ success: false, error: error.message });
        });
        return true;
    }
    
    // 获取API URL
    if (request.action === "getApiUrl") {
        chrome.storage.sync.get('apiUrl', (data) => {
            sendResponse({ apiUrl: data.apiUrl });
        });
        return true;
    }
});

// 下载图片
async function downloadImage(url) {
    try {
        const urlObj = new URL(url);
        let filename = urlObj.pathname.split('/').pop();
        
        if (!filename || !filename.includes('.')) {
            filename = 'image_' + Date.now() + '.jpg';
        }
        
        await chrome.downloads.download({
            url: url,
            filename: filename,
            saveAs: false
        });
        
        return { success: true };
    } catch (error) {
        console.error('Download error:', error);
        throw error;
    }
}

// MIME类型转扩展名
function mimeToExtension(mimeType) {
    if (!mimeType) return null;
    const mimeMap = {
        'image/jpeg': 'jpg',
        'image/png': 'png',
        'image/gif': 'gif',
        'image/webp': 'webp',
        'image/bmp': 'bmp',
        'image/tiff': 'tiff',
        'image/avif': 'avif'
    };
    return mimeMap[mimeType.toLowerCase()] || null;
}

// 处理图片上传
async function handleImageUpload(imageUrl) {
    try {
        const { apiUrl, apiKey, outputFormat } = await chrome.storage.sync.get(['apiUrl', 'apiKey', 'outputFormat']);
        if (!apiUrl) {
            showNotification("上传失败", "请先在扩展选项中设置API地址。");
            return { success: false, error: "请先在扩展选项中设置API地址。" };
        }

        const response = await fetch(imageUrl);
        if (!response.ok) {
            throw new Error(`网络响应错误: ${response.statusText}`);
        }
        const imageBlob = await response.blob();
        
        if (imageBlob.size === 0) {
            throw new Error("无法获取图片数据，文件为空。");
        }

        const mimeType = imageBlob.type;
        const extension = mimeToExtension(mimeType);

        const allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'bmp', 'tiff', 'avif', 'gif'];
        if (!extension || !allowedExtensions.includes(extension)) {
            const errorMsg = `不支持的图片格式: ${mimeType || '未知'}`;
            showNotification("上传失败", errorMsg);
            return { success: false, error: errorMsg };
        }
        
        const filename = `upload.${extension}`;

        const formData = new FormData();
        formData.append('image', imageBlob, filename);

        const finalOutputFormat = outputFormat || 'auto';
        if (finalOutputFormat !== 'auto') {
            formData.append('outputFormat', finalOutputFormat);
        }

        if (apiKey) {
            formData.append('apiKey', apiKey);
        }
        
        const uploadResponse = await fetch(apiUrl, {
            method: 'POST',
            body: formData
        });

        if (!uploadResponse.ok) {
            const errorText = await uploadResponse.text();
            throw new Error(`服务器错误 ${uploadResponse.status}: ${errorText}`);
        }

        const result = await uploadResponse.json();

        if (result && result.success && result.url) {
            const uploadedUrl = result.url;
            await saveToHistory(uploadedUrl);
            showNotification("上传成功！", "请在扩展页面历史上传中找到该图片。");
            return { success: true, url: uploadedUrl };
        } else {
            const errorMsg = result.message || "服务器返回未知错误。";
            showNotification("上传失败", errorMsg);
            return { success: false, error: errorMsg };
        }

    } catch (error) {
        console.error('上传时发生错误:', error);
        showNotification("上传失败", error.message || "网络错误或API无法访问。");
        return { success: false, error: error.message };
    }
}

// 历史记录保存
const MAX_HISTORY_ITEMS = 15;

async function saveToHistory(newUrl) {
    return new Promise((resolve) => {
        chrome.storage.local.get({ uploadHistory: [] }, (data) => {
            let history = data.uploadHistory || [];
            history = history.filter(item => item.url !== newUrl);
            history.unshift({ url: newUrl, time: new Date().toISOString() });
            if (history.length > MAX_HISTORY_ITEMS) {
                history = history.slice(0, MAX_HISTORY_ITEMS);
            }
            chrome.storage.local.set({ uploadHistory: history }, () => {
                resolve();
            });
        });
    });
}

// 显示通知
function showNotification(title, message) {
    chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: title,
        message: message,
        priority: 2
    });
}