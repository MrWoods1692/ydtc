let dropZone;
let dragCounter = 0; // 用于处理嵌套拖拽事件的计数器
let isInitialized = false; // 标记是否已初始化

// 1. 初始化和销毁拖拽功能
function initializeDragUpload() {
    if (isInitialized) return;
    window.addEventListener('dragenter', handleDragEnter, true);
    window.addEventListener('dragleave', handleDragLeave, true);
    window.addEventListener('drop', handleWindowDrop, true);
    window.addEventListener('dragover', handleDragOverWindow, true);
    isInitialized = true;
}

function destroyDragUpload() {
    if (!isInitialized) return;
    window.removeEventListener('dragenter', handleDragEnter, true);
    window.removeEventListener('dragleave', handleDragLeave, true);
    window.removeEventListener('drop', handleWindowDrop, true);
    window.removeEventListener('dragover', handleDragOverWindow, true);
    hideDropZone();
    isInitialized = false;
}

// 2. 检查设置并启动
chrome.storage.sync.get({ dragUploadEnabled: true }, (items) => {
    if (items.dragUploadEnabled) {
        initializeDragUpload();
    }
});

// 3. 监听设置变化
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && changes.dragUploadEnabled) {
        const newValue = changes.dragUploadEnabled.newValue;
        if (newValue) {
            initializeDragUpload();
        } else {
            destroyDragUpload();
        }
    }
});

// --- 事件处理器 (函数名修改以避免混淆) ---
function handleDragEnter(e) {
    if (dragCounter === 0) {
        if (e.dataTransfer.types.some(t => ['Files', 'text/uri-list', 'text/html'].includes(t))) {
            showDropZone();
        }
    }
    dragCounter++;
}

function handleDragLeave(e) {
    dragCounter--;
    if (dragCounter <= 0) {
        dragCounter = 0;
        hideDropZone();
    }
}

function handleWindowDrop(e) {
    dragCounter = 0;
    hideDropZone();
}

function handleDragOverWindow(e) {
    e.preventDefault();
}

// --- 拖放区域的创建和事件 (大部分不变) ---
function createOrGetDropZone() {
    let zone = document.getElementById('tuchuang-drop-zone');
    if (!zone) {
        zone = document.createElement('div');
        zone.id = 'tuchuang-drop-zone';
        zone.textContent = '拖到此处上传';
        document.body.appendChild(zone);
        zone.addEventListener('dragover', handleZoneDragOver);
        zone.addEventListener('dragleave', handleZoneDragLeave);
        zone.addEventListener('drop', handleZoneDrop);
    }
    return zone;
}

function handleZoneDragOver(e) { e.preventDefault(); e.stopPropagation(); e.currentTarget.classList.add('dragover'); }
function handleZoneDragLeave(e) { e.preventDefault(); e.stopPropagation(); e.currentTarget.classList.remove('dragover'); }
function handleZoneDrop(e) {
    e.preventDefault();
    e.stopPropagation();

    let imageUrl;
    const html = e.dataTransfer.getData('text/html');
    if (html) {
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = html;
        const img = tempDiv.querySelector('img');
        if (img) { imageUrl = img.src; }
    }
    if (!imageUrl) {
        imageUrl = e.dataTransfer.getData('text/uri-list');
    }
    if (imageUrl) {
        chrome.runtime.sendMessage({ action: 'uploadFromUrl', url: imageUrl });
    }
    dragCounter = 0;
    hideDropZone();
}

function showDropZone() {
    const zone = createOrGetDropZone();
    zone.classList.add('visible');
}

function hideDropZone() {
    const zone = document.getElementById('tuchuang-drop-zone');
    if (zone) {
        zone.classList.remove('visible', 'dragover');
    }
} 